jQuery-Picture
==============

jQuery plugin to handle responsive images.

Read the guide <a href="http://jquerypicture.com">here</a>.